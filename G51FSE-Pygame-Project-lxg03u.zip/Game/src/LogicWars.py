#!/usr/bin/env python

from MainLoop import MainLoop

"""main function where the game runs"""						
def main():
	loop = MainLoop()
	loop.gameLoop()

#makes the game script run the main function
if __name__ == "__main__":
	main()
